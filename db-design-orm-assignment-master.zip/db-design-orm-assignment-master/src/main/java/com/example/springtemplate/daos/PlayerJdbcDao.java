package com.example.springtemplate.daos;
import com.example.springtemplate.models.Player;
import com.example.springtemplate.models.User;

import java.sql.*;
import java.util.*;

public class PlayerJdbcDao {
  static final String DRIVER = "com.mysql.cj.jdbc.Driver";
  static final String HOST = "localhost:3306";
  static final String SCHEMA = "db_final_project";
  static final String CONFIG = "serverTimezone=UTC";
  static final String URL =
      "jdbc:mysql://"+HOST+"/"+SCHEMA+"?"+CONFIG;
  static final String USERNAME = "root";
  static final String PASSWORD = "Sanvi#123";

  static Connection connection = null;
  static PreparedStatement statement = null;
  String CREATE_USER = "INSERT INTO player VALUES (null, ?, ?, ?, ?)";
  String FIND_ALL_USERS = "SELECT * FROM player";
  String FIND_USER_BY_ID = "SELECT * FROM player WHERE id=?";
  String DELETE_USER = "DELETE FROM player WHERE id=?";

  String UPDATE_USER = "UPDATE player SET first_name=?, last_name=?, jersey_number=?, team=?, "
      + "WHERE id=?";

  private Connection getConnection() throws ClassNotFoundException, SQLException {
    Class.forName(DRIVER);
    return DriverManager.getConnection(URL, USERNAME, PASSWORD);
  }

  private void closeConnection(Connection connection) throws SQLException {
    connection.close();
  }

  public Player findPlayerById(Integer id) throws SQLException, ClassNotFoundException {
    Player player = null;
    connection = getConnection();
    statement = connection.prepareStatement(FIND_USER_BY_ID);
    statement.setInt(1, id);
    ResultSet resultSet = statement.executeQuery();
    if(resultSet.next()) {
      player = new Player(
          resultSet.getString("first_name"),
          resultSet.getString("last_name"),
          resultSet.getInt("jersey_number"),
          resultSet.getInt("team")
      );
    }
    closeConnection(connection);
    return player;
  }

  public Integer deletePlayer(Integer userId) throws SQLException, ClassNotFoundException {
    Integer rowsDeleted = 0;
    connection = getConnection();
    statement = connection.prepareStatement(DELETE_USER);
    statement.setInt(1, userId);
    rowsDeleted = statement.executeUpdate();
    closeConnection(connection);
    return rowsDeleted;
  }

  public Integer updatePlayer(Integer userId, Player newUser) throws SQLException,
      ClassNotFoundException {
    Integer rowsUpdated = 0;
    connection = getConnection();
    statement = connection.prepareStatement(UPDATE_USER);
    statement.setString(1, newUser.getFirstName());
    statement.setString(2, newUser.getLastName());
    statement.setInt(3, newUser.getJerseyNumber());
    statement.setInt(4, newUser.getTeam());
    statement.setInt(5, userId);
    rowsUpdated = statement.executeUpdate();
    closeConnection(connection);
    return rowsUpdated;
  }

  public List<Player> findAllPlayer() throws ClassNotFoundException, SQLException {
    List<Player> players = new ArrayList<Player>();
    connection = getConnection();
    statement = connection.prepareStatement(FIND_ALL_USERS);
    ResultSet resultSet = statement.executeQuery();
    while (resultSet.next()) {
      Player player = new Player(
          resultSet.getString("first_name"),
          resultSet.getString("last_name"),
          resultSet.getInt("jersey_number"),
          resultSet.getInt("team")
      );
      players.add(player);
    }
    closeConnection(connection);
    return players;
  }
  public Integer createPlayer(Player player)
      throws ClassNotFoundException, SQLException {
    Integer rowsUpdated = 0;
    connection = getConnection();
    statement = connection.prepareStatement(CREATE_USER);
    statement.setString(1, player.getFirstName());
    statement.setString(2, player.getLastName());
    statement.setInt(3, player.getJerseyNumber());
    statement.setInt(4, player.getTeam());

    rowsUpdated = statement.executeUpdate();
    closeConnection(connection);
    return rowsUpdated;
  }
  public static void main(String[] args) throws SQLException, ClassNotFoundException {
    System.out.println("JDBC DAO");
    PlayerJdbcDao dao = new PlayerJdbcDao();
//        User adam = new User("Adam", "Smith", "adams", "invisiblehand", "http://bbc.in/30gXhI4");
//        User catherine = new User("Catherine", "Wood", "cathie", "bitcoinisbig", "https://ark-invest.com/");
//        dao.createUser(adam);
//        dao.createUser(thomas);
//        dao.createUser(catherine);
//        List<User> users = dao.findAllUsers();
//        for(User user: users) {
//            System.out.println(user.getUsername());
//        }
//        User user = dao.findUserById(5);
//        System.out.println(user.getUsername());
//        dao.deleteUser(5);
//        List<User> users = dao.findAllUsers();
//        for(User user: users) {
//            System.out.println(user.getUsername());
//        }
    //User thomas = new User("Thomas", "Sowell", "thomas", "polymath", "thomas@gmail.com",
    // null);

    Player luka = dao.findPlayerById(1);
    System.out.println(luka.getFirstName());
  }
}