package com.example.springtemplate.models;

import com.fasterxml.jackson.annotation.JsonIgnore;
import java.sql.Date;
import java.util.List;
import javax.persistence.*;

@Entity
@Table(name="favorites")
public class Favorites {
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Integer id;

  private Integer user;
  private Integer player;
  private Integer team;


  public Integer getId() { return id; }
  public void setId(Integer id) { this.id = id; }
  public Integer getUserId() { return user; }
  public void setUserId(Integer firstName) { this.user = firstName; }
  public Integer getPlayerId() { return player; }
  public void setPlayerId(Integer lastName) { this.player = lastName; }
  public Integer getTeamId() { return this.team; }
  public void setTeamId(Integer jerseyNumber) { this.team = jerseyNumber; }


  public Favorites(int userId, int playerId, int teamId) {
    this.user = userId;
    this.player = playerId;
    this.team = teamId;
  }

  public Favorites() {}
}
