package com.example.springtemplate.daos;

import com.example.springtemplate.models.Player;
import com.example.springtemplate.repositories.PlayerRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@CrossOrigin(origins = "*")
public class PlayerOrmDao {
  @Autowired
  PlayerRepository playerRepository;

  @PostMapping("/api/player")
  public Player createPlayer(@RequestBody Player player) {
    return playerRepository.save(player);
  }

  @GetMapping("/api/player")
  public List<Player> findAllPlayers() {
    return playerRepository.findAllPlayers();
  }

  @GetMapping("/api/player/{playerId}")
  public Player findPlayerById(
      @PathVariable("playerId") Integer id) {
    return playerRepository.findPlayerById(id);
  }

  @PutMapping("/api/player/{playerId}")
  public Player updatePlayer(
      @PathVariable("playerId") Integer id,
      @RequestBody Player userUpdates) {
    Player player = playerRepository.findPlayerById(id);
    player.setFirstName(userUpdates.getFirstName());
    player.setLastName(userUpdates.getLastName());
    player.setJerseyNumber(userUpdates.getJerseyNumber());
    player.setTeam(userUpdates.getTeam());
    return playerRepository.save(player);
  }

  @DeleteMapping("/api/player/{playerId}")
  public void deletePlayer(
      @PathVariable("playerId") Integer id) {
    playerRepository.deleteById(id);
  }
}