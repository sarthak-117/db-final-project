package com.example.springtemplate.models;

public enum Status {
  PLAYED("PLAYED"),
  CURRENT("CURRENT"),
  UPCOMING("UPCOMING");

  private String type;
  Status(String stat) {
    this.type = stat;
  }

  public static Status getStatus(String stat) {
    for (Status suit : Status.values()) {
      if (suit.type.equals(stat)) {
        return suit;
      }
    }
    return null;
  }

  public String getType() {
    return this.type;
  }

}
