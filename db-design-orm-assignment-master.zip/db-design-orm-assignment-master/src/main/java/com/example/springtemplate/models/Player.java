package com.example.springtemplate.models;

import com.fasterxml.jackson.annotation.JsonIgnore;
import java.sql.Date;
import java.util.List;
import javax.persistence.*;

@Entity
@Table(name="player")
public class Player {
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Integer id;
  private String firstName;
  private String lastName;
  private Integer jerseyNumber;
  private Integer team;


  @ManyToMany
  @JsonIgnore
  private List<User> users;

  public Integer getId() { return id; }
  public void setId(Integer id) { this.id = id; }
  public String getFirstName() { return firstName; }
  public void setFirstName(String firstName) { this.firstName = firstName; }
  public String getLastName() { return lastName; }
  public void setLastName(String lastName) { this.lastName = lastName; }
  public Integer getJerseyNumber() { return this.jerseyNumber; }
  public void setJerseyNumber(Integer jerseyNumber) { this.jerseyNumber = jerseyNumber; }
  public Integer getTeam() { return this.team;}
  public void setTeam(Integer team) { this.team = team; }

  public Player(String first_name, String last_name,
      int jersey_number, int team) {
    this.firstName = first_name;
    this.lastName = last_name;
    this.jerseyNumber = jersey_number;
    this.team = team;
  }

  public Player() {}
}
