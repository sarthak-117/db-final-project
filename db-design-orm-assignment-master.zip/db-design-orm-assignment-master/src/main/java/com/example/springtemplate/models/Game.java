package com.example.springtemplate.models;

import java.sql.Date;
import javax.persistence.*;


@Entity
@Table(name="game")
public class Game {
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Integer id;
  private Integer location;
  private Integer teamOne;
  private Integer teamTwoPoints;
  private String favoriteTeam;
  private Integer spread;
  @Enumerated(EnumType.STRING)
  private Status status;


  public Integer getId() { return id; }
  public void setId(Integer id) { this.id = id; }
  public Integer getLocation() { return this.location; }
  public void setLocation(int location) { this.location = location; }
  public Integer getTeamOne() { return teamOne; }
  public void setTeamOne(int team1Points) { this.teamOne = team1Points; }
  public Integer getTeamTwoPoints() { return teamTwoPoints; }
  public void setTeamTwoPoints(int team2Points) { this.teamTwoPoints = team2Points; }
  public String getFavoriteTeam() { return favoriteTeam; }
  public void setFavoriteTeam(String team) { this.favoriteTeam = team; }
  public Integer getSpread() { return this.spread; }
  public void setSpread(int spread) { this.spread = spread; }
  public Status getStatus() { return this.status; }
  public void setStatus(String stat) { this.status = Status.getStatus(stat); }

  public Game(int location, int team1Points, int team2Points, String favoriteTeam,
      int spread, String stat) {
    this.location = location;
    this.teamOne = team1Points;
    this.teamTwoPoints = team2Points;
    this.favoriteTeam = favoriteTeam;
    this.spread = spread;
    this.status = Status.getStatus(stat);
  }

  public Game() {}
}