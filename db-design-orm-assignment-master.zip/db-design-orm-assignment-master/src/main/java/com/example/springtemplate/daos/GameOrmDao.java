package com.example.springtemplate.daos;

import com.example.springtemplate.models.Game;
import com.example.springtemplate.models.User;
import com.example.springtemplate.repositories.GameRepository;
import com.example.springtemplate.repositories.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@CrossOrigin(origins = "*")
public class GameOrmDao {
  @Autowired
  GameRepository gameRepository;

  @PostMapping("/api/game")
  public Game createGame(@RequestBody Game user) {
    return gameRepository.save(user);
  }

  @GetMapping("/api/game")
  public List<Game> findAllGames() {
    return gameRepository.findAllGames();
  }

  @GetMapping("/api/game/{gameId}")
  public Game findGameById(
      @PathVariable("gameId") Integer id) {
    return gameRepository.findGameById(id);
  }

  @PutMapping("/api/game/{gameId}")
  public Game updateGame(
      @PathVariable("gameId") Integer id,
      @RequestBody Game userUpdates) {
    Game game = gameRepository.findGameById(id);
    game.setLocation(userUpdates.getLocation());
    game.setTeamOne(userUpdates.getTeamOne());
    game.setTeamTwoPoints(userUpdates.getTeamTwoPoints());
    game.setFavoriteTeam(userUpdates.getFavoriteTeam());
    game.setSpread(userUpdates.getSpread());
    game.setStatus(userUpdates.getStatus().getType());
    return gameRepository.save(game);
  }

  @DeleteMapping("/api/game/{gameId}")
  public void deleteUser(
      @PathVariable("gameId") Integer id) {
    gameRepository.deleteById(id);
  }
}