package com.example.springtemplate.daos;
import com.example.springtemplate.models.Player;
import com.example.springtemplate.models.Game;

import java.sql.*;
import java.util.*;

public class GameJdbcDao {
  static final String DRIVER = "com.mysql.cj.jdbc.Driver";
  static final String HOST = "localhost:3306";
  static final String SCHEMA = "db_final_project";
  static final String CONFIG = "serverTimezone=UTC";
  static final String URL =
      "jdbc:mysql://"+HOST+"/"+SCHEMA+"?"+CONFIG;
  static final String USERNAME = "root";
  static final String PASSWORD = "P@SSWORD";

  static Connection connection = null;
  static PreparedStatement statement = null;
  String CREATE_USER = "INSERT INTO game VALUES (null, ?, ?, ?, ?, ?, ?)";
  String FIND_ALL_USERS = "SELECT * FROM game";
  String FIND_USER_BY_ID = "SELECT * FROM game WHERE id=?";
  String DELETE_USER = "DELETE FROM game WHERE id=?";

  String UPDATE_USER = "UPDATE game SET location=?, team_one=?, team_two_points=?, "
      + "favorite_team=?, spread=?, status=?"
      + "WHERE id=?";

  private Connection getConnection() throws ClassNotFoundException, SQLException {
    Class.forName(DRIVER);
    return DriverManager.getConnection(URL, USERNAME, PASSWORD);
  }

  private void closeConnection(Connection connection) throws SQLException {
    connection.close();
  }

  public Game findGameById(Integer id) throws SQLException, ClassNotFoundException {
    Game game = null;
    connection = getConnection();
    statement = connection.prepareStatement(FIND_USER_BY_ID);
    statement.setInt(1, id);
    ResultSet resultSet = statement.executeQuery();
    if(resultSet.next()) {
      game = new Game(
          resultSet.getInt("location"),
          resultSet.getInt("team_one"),
          resultSet.getInt("team_two_points"),
          resultSet.getString("favorite_team"),
          resultSet.getInt("spread"),
          resultSet.getString("status")
      );
    }
    closeConnection(connection);
    return game;
  }

  public Integer deleteGame(Integer userId) throws SQLException, ClassNotFoundException {
    Integer rowsDeleted = 0;
    connection = getConnection();
    statement = connection.prepareStatement(DELETE_USER);
    statement.setInt(1, userId);
    rowsDeleted = statement.executeUpdate();
    closeConnection(connection);
    return rowsDeleted;
  }

  public Integer updateGame(Integer userId, Game newGame) throws SQLException,
      ClassNotFoundException {
    Integer rowsUpdated = 0;
    connection = getConnection();
    statement = connection.prepareStatement(UPDATE_USER);
    statement.setInt(1, newGame.getLocation());
    statement.setInt(2, newGame.getTeamOne());
    statement.setInt(3, newGame.getTeamTwoPoints());
    statement.setString(4, newGame.getFavoriteTeam());
    statement.setInt(5, newGame.getSpread());
    statement.setString(6, newGame.getStatus().getType());
    statement.setInt(7, userId);
    rowsUpdated = statement.executeUpdate();
    closeConnection(connection);
    return rowsUpdated;
  }

  public List<Game> findAllGames() throws ClassNotFoundException, SQLException {
    List<Game> games = new ArrayList<Game>();
    connection = getConnection();
    statement = connection.prepareStatement(FIND_ALL_USERS);
    ResultSet resultSet = statement.executeQuery();
    while (resultSet.next()) {
      Game game = new Game(
          resultSet.getInt("location"),
          resultSet.getInt("team_one"),
          resultSet.getInt("team_two_points"),
          resultSet.getString("favorite_team"),
          resultSet.getInt("spread"),
          resultSet.getString("status")
      );
      games.add(game);
    }
    closeConnection(connection);
    return games;
  }
  public Integer createGame(Game game)
      throws ClassNotFoundException, SQLException {
    Integer rowsUpdated = 0;
    connection = getConnection();
    statement = connection.prepareStatement(CREATE_USER);
    statement.setInt(1, game.getLocation());
    statement.setInt(2,game.getTeamOne());
    statement.setInt(3,game.getTeamTwoPoints());
    statement.setString(4, game.getFavoriteTeam());
    statement.setInt(5, game.getSpread());
    statement.setString(6,game.getStatus().getType());

    rowsUpdated = statement.executeUpdate();
    closeConnection(connection);
    return rowsUpdated;
  }
  public static void main(String[] args) throws SQLException, ClassNotFoundException {
    System.out.println("JDBC DAO");
    GameJdbcDao dao = new GameJdbcDao();
//        User adam = new User("Adam", "Smith", "adams", "invisiblehand", "http://bbc.in/30gXhI4");
//        User catherine = new User("Catherine", "Wood", "cathie", "bitcoinisbig", "https://ark-invest.com/");
//        dao.createUser(adam);
//        dao.createUser(thomas);
//        dao.createUser(catherine);
//        List<User> users = dao.findAllUsers();
//        for(User user: users) {
//            System.out.println(user.getUsername());
//        }
//        User user = dao.findUserById(5);
//        System.out.println(user.getUsername());
//        dao.deleteUser(5);
//        List<User> users = dao.findAllUsers();
//        for(User user: users) {
//            System.out.println(user.getUsername());
//        }
    //User thomas = new User("Thomas", "Sowell", "thomas", "polymath", "thomas@gmail.com",
    // null);
    // Game g2 = new Game(2, 10, 20 , "Los Angeles Lakers", -1, "CURRENT");
  //  dao.createGame(g2);
    Game g1 = dao.findGameById(1);
    System.out.println(g1.getTeamTwoPoints());
  }
}