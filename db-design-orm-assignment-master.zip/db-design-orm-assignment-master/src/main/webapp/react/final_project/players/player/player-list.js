const {Link, useHistory} = window.ReactRouterDOM;
import playerService from "./player-service"
const { useState, useEffect } = React;


const PlayerList = () => {
  const [users, setUsers] = useState([])
  const history = useHistory()

  useEffect(() => {
    findAllPlayers()
  }, [])
  const findAllPlayers = () =>
      playerService.findAllPlayers()
      .then(users => setUsers(users))

  return(
        <div>
            <h2>Player List</h2>
          <button onClick={() => history.push("/player/new")}>
            Add Player
          </button>

            <ul className="list-group">
              {
                users.map(user =>
                    <li className="list-group-item" key={user.id}>
                      <Link to={`/player/${user.id}`}>
                        {user.firstName},
                        {user.lastName},
                        {user.jerseyNumber}
                      </Link>
                    </li>)
              }
            </ul>

        </div>
    )
}

export default PlayerList;