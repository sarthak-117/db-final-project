import PlayerList from "./player/player-list";
import PlayerFormEditor from "./player/player-form-editor";
import SectionList from "../../university/sections/section-list";
const {HashRouter, Route} = window.ReactRouterDOM; 
const App = () => {
    return (
        <div className="container-fluid">
            <HashRouter>
                <Route path={["/player", "/"]} exact={true}>
                    <PlayerList/>
                </Route>
                <Route path="/player/:id" exact={true}>
                    <PlayerFormEditor/>
                </Route>
                {/*
                <Route path="/users/:userId/player" exact={true}>
                    <PlayerList/>
                </Route>
                <Route path="/player/:playerId" exact={true}>
                    <PlayerListFormEditor/>
                </Route>

                <Route path="/users/:userId/game" exact={true}>
                    <GameList/>
                </Route>
                <Route path="/game/:gameId" exact={true}>
                    <GameListFormEditor/>
                </Route>*/}
            </HashRouter>
        </div>
    );
}

export default App;
