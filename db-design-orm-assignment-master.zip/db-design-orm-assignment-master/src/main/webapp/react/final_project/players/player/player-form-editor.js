import playerService from "./player-service"
const {useState, useEffect} = React;
const {useParams, useHistory, Link} = window.ReactRouterDOM;
const PlayerFormEditor = () => {
        const {id} = useParams()
        const findUserById = (id) => playerService.findPlayerById(id).then(user => setUser(user))
        const deleteUser = (id) => playerService.deletePlayer(id).then(()=>history.back())
        const createUser = (user) =>
            playerService.createPlayer(user)
            .then(() => history.back())
        const updateUser = (id, newUser) =>
            playerService.updatePlayer(id, newUser)
            .then(() => history.back())



        const [user, setUser] = useState({})
            useEffect(() => {
                if(id !== "new") {
                        findUserById(id)
                }
        }, []);

        return (
        <div>
            <h2>Player Editor</h2>
            <label>Id</label>
            <input value={user.id}/><br/>
            <label>First Name</label>
                <input
                    onChange={(e) =>
                        setUser(user =>
                            ({...user, firstName: e.target.value}))}
                    value={user.firstName}/>
                <label>Last Name</label>
                <input
                    onChange={(e) =>
                        setUser(user =>
                            ({...user, lastName: e.target.value}))}
                    value={user.lastName}/>
                <label>Jersey Number</label>
                <input
                    onChange={(e) =>
                        setUser(user =>
                            ({...user, jerseyNumber: e.target.value}))}
                    value={user.jerseyNumber}/>

          <label>Team</label>
          <input
              onChange={(e) =>
                  setUser(user =>
                      ({...user, team: e.target.value}))}
              value={user.team}/>




                <button className="btn btn-cancel"
                    onClick={() => {
                            history.back()}}>
                        Cancel
                </button>

            <button onClick={() => deleteUser(user.id)} className="btn btn-danger">Delete</button>
            <button onClick={() => updateUser(user.id, user)} className="btn btn-primary">Save</button>
            <button  onClick={() => createUser(user)} className="btn btn-success">Create</button>

          <Link to={`/player/${user.id}/game`}>
            games
          </Link>

        </div>
    )
}

export default PlayerFormEditor