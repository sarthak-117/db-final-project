import gameService from "./game-service"
const {useState, useEffect} = React;
const {useParams, useHistory} = window.ReactRouterDOM;
const GameFormEditor = () => {
        const {id} = useParams()
        const findUserById = (id) => gameService.findGameById(id).then(user => setUser(user))
        const deleteUser = (id) => gameService.deleteGame(id).then(()=>history.back())
        const createUser = (user) =>
            gameService.createGame(user)
            .then(() => history.back())
        const updateUser = (id, newUser) =>
            gameService.updateGame(id, newUser)
            .then(() => history.back())



        const [user, setUser] = useState({})
            useEffect(() => {
                if(id !== "new") {
                        findUserById(id)
                }
        }, []);

        return (
        <div>
            <h2>Game Editor</h2>
            <label>Id</label>
            <input value={user.id}/><br/>
            <label>Location</label>
                <input
                    onChange={(e) =>
                        setUser(user =>
                            ({...user, location: e.target.value}))}
                    value={user.location}/>
                <label>Team 1 Points</label>
                <input
                    onChange={(e) =>
                        setUser(user =>
                            ({...user, teamOne: e.target.value}))}
                    value={user.teamOne}/>
                <label>Team 2 Points</label>
                <input
                    onChange={(e) =>
                        setUser(user =>
                            ({...user, teamTwoPoints: e.target.value}))}
                    value={user.teamTwoPoints}/>
                <label>Favorite Team</label>
                <input
                    onChange={(e) =>
                        setUser(user =>
                            ({...user, favoriteTeam: e.target.value}))}
                    value={user.favoriteTeam}/>
          <label>Spread</label>
          <input
              onChange={(e) =>
                  setUser(user =>
                      ({...user, spread: e.target.value}))}
              value={user.spread}/>
          <label>Status</label>
          <input
              onChange={(e) =>
                  setUser(user =>
                      ({...user, status: e.target.value}))}
              value={user.status}/>



                <button className="btn btn-cancel"
                    onClick={() => {
                            history.back()}}>
                        Cancel
                </button>

            <button onClick={() => deleteUser(user.id)} className="btn btn-danger">Delete</button>
            <button onClick={() => updateUser(user.id, user)} className="btn btn-primary">Save</button>
            <button  onClick={() => createUser(user)} className="btn btn-success">Create</button>
        </div>
    )
}

export default GameFormEditor