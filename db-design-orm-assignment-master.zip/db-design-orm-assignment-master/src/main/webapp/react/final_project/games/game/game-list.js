const {Link, useHistory} = window.ReactRouterDOM;
import gameService from "./game-service"
const { useState, useEffect } = React;


const GameList = () => {
  const [games, setGames] = useState([])
  const history = useHistory()

  useEffect(() => {
    findAllGames()
  }, [])
  const findAllGames = () =>
      gameService.findAllGames()
      .then(games => setGames(games))

  return(
        <div>
            <h2>Game List</h2>
          <button onClick={() => history.push("/game/new")}>
            Add Game
          </button>

            <ul className="list-group">
              {
                games.map(game =>
                    <li className="list-group-item" key={game.id}>
                      <Link to={`/game/${game.id}`}>
                        {game.favoriteTeam},

                      </Link>
                    </li>)
              }


            </ul>

          <Link to={`/users`}>
            users
          </Link>

          <div/>

          <Link to={`/player`}>
            players
          </Link>


        </div>
    )
}

export default GameList;