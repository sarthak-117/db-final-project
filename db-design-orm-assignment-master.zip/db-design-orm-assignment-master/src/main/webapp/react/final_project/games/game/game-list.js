const {Link, useHistory} = window.ReactRouterDOM;
import gameService from "./game-service"
const { useState, useEffect } = React;


const GameList = () => {
  const [games, setGames] = useState([])
  const history = useHistory()

  useEffect(() => {
    findAllGames()
  }, [])
  const findAllGames = () =>
      gameService.findAllGames()
      .then(games => setGames(games))

  return(
        <div>
            <h2>Game List</h2>
          <button onClick={() => history.push("/game/new")}>
            Add Game
          </button>

            <ul className="list-group">
              {
                games.map(game =>
                    <li className="list-group-item" key={game.id}>
                      <Link to={`/game/${game.id}`}>
                        {game.favoriteTeam},

                      </Link>
                    </li>)
              }


            </ul>



        </div>
    )
}

export default GameList;