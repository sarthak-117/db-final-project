import UserList from "./users/user-list";
import UserFormEditor from "./users/user-form-editor";
import SectionList from "../../university/sections/section-list";
import PlayerList from "../players/player/player-list";
import PlayerFormEditor from "../players/player/player-form-editor";
import GameList from "../games/game/game-list";
import GameFormEditor from "../games/game/game-form-editor";
const {HashRouter, Route} = window.ReactRouterDOM; 
const App = () => {
    return (
        <div className="container-fluid">
            <HashRouter>
                <Route path={["/users", "/"]} exact={true}>
                    <UserList/>
                </Route>
                <Route path="/users/:id" exact={true}>
                    <UserFormEditor/>
                </Route>
                <Route path="/users/:userId/player" exact={true}>
                    <PlayerList/>
                </Route>
                <Route path="/player" exact={true}>
                    <PlayerList/>
                </Route>
                <Route path="/player/:id" exact={true}>
                    <PlayerFormEditor/>
                </Route>

                <Route path="/player/:playerId/game" exact={true}>
                    <GameList/>
                </Route>
                <Route path="/game" exact={true}>
                    <GameList/>
                </Route>
                <Route path="/game/:id" exact={true}>
                    <GameFormEditor/>
                </Route>
            </HashRouter>
        </div>
    );
}

export default App;
