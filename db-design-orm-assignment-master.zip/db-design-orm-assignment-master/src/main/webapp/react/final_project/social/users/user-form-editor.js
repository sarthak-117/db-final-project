import userService from "./user-service"

const {useState, useEffect} = React;
const {useParams, useHistory} = window.ReactRouterDOM;
const {Link} = window.ReactRouterDOM;
const UserFormEditor = () => {
        const {id} = useParams()
        const findUserById = (id) => userService.findUserById(id).then(user => setUser(user))
        const deleteUser = (id) => userService.deleteUser(id).then(()=>history.back())
        const createUser = (user) =>
            userService.createUser(user)
            .then(() => history.back())
        const updateUser = (id, newUser) =>
            userService.updateUser(id, newUser)
            .then(() => history.back())

  const [player, setPlayers] = useState({players:[]})




        const [user, setUser] = useState({})
            useEffect(() => {
                if(id !== "new") {
                        findUserById(id)
                }
        }, []);

        return (
        <div>
            <h2>User Editor</h2>
            <label>Id</label>
            <input value={user.id}/><br/>
            <label>First Name</label>
                <input
                    onChange={(e) =>
                        setUser(user =>
                            ({...user, firstName: e.target.value}))}
                    value={user.firstName}/>
                <label>Last Name</label>
                <input
                    onChange={(e) =>
                        setUser(user =>
                            ({...user, lastName: e.target.value}))}
                    value={user.lastName}/>
                <label>Username</label>
                <input
                    onChange={(e) =>
                        setUser(user =>
                            ({...user, username: e.target.value}))}
                    value={user.username}/>
                <label>Password</label>
                <input
                    type="password"
                    onChange={(e) =>
                        setUser(user =>
                            ({...user, password: e.target.value}))}
                    value={user.password}/>
          <label>Email</label>
          <input
              onChange={(e) =>
                  setUser(user =>
                      ({...user, email: e.target.value}))}
              value={user.email}/>
          <label>Date Of Birth</label>
          <input type = "date"
              onChange={(e) =>
                  setUser(user =>
                      ({...user, dateOfBirth: e.target.value}))}
              value={user.dateOfBirth}/>




                <button className="btn btn-cancel"
                    onClick={() => {
                            history.back()}}>
                        Cancel
                </button>

            <button onClick={() => deleteUser(user.id)} className="btn btn-danger">Delete</button>
            <button onClick={() => updateUser(user.id, user)} className="btn btn-primary">Save</button>
            <button  onClick={() => createUser(user)} className="btn btn-success">Create</button>


          <Link to={`/users/${user.id}/player`}>
            players
          </Link>

          <ul>{
            user.id !== "new" && player.players.map(s =>

            <li> <Link to={`user/${user.id}/player`}>
            player
            </Link>
            </li>
            )
          }
          </ul>


        </div>
    )
}

export default UserFormEditor